s = raw_input('Enter your name: ')
print 'you entered', s

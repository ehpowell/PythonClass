from typing import Any, List

def simpfunc(x: int) -> List[int]:
   print(x)
   return [1, 0]

f: float = 34.0
g: int = 1

f = simpfunc(3)

g = simpfunc(1)


# CorePython
Materials for Core Python course
